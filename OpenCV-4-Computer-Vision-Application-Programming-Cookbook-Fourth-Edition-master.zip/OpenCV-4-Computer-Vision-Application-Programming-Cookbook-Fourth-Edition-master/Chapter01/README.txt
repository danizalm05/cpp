This directory contains material supporting chapter 1 of the cookbook:  
Computer Vision Programming using the OpenCV Library. 
Third Edition
by Robert Laganiere, Packt Publishing, 2016.


File:
	loadDisplaySave.cpp
corresponds to Recipe:
Loading, displaying and saving images

File:
	mat.cpp
corresponds to Recipe:
Exploring the cv::Mat data structure

File:
	logo.cpp
corresponds to Recipe:
Defining region of interest