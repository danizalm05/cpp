This directory contains material supporting chapter 2 of the cookbook:  
Computer Vision Programming using the OpenCV Library. 
Third Edition
by Robert Laganiere, Packt Publishing, 2016.

File:
	saltImage.cpp
correspond to Recipe:
Accessing the pixel values

File:
	colorReduce.cpp
correspond to Recipes:
Scanning an image with pointers
Scanning an image with iterators
Writing efficient image scanning loops

File:
	contrast.cpp
correspond to Recipe:
Scanning an image with neighbour access

File:
	addImages.cpp
correspond to Recipes:
Performing simple image arithmetic

File:
	remapping.cpp
correspond to Recipes:
Remapping an image

You need the images:
boldt.jpg
rain.jpg