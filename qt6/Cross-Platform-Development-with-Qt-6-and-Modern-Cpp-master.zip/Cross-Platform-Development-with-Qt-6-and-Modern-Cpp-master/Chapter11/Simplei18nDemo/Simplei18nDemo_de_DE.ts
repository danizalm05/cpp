<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>CustomWidget</name>
    <message>
        <location filename="customwidget.ui" line="14"/>
        <source>Simple i18n Demo</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Einfache i18n Demo</translation>
    </message>
    <message>
        <location filename="customwidget.ui" line="25"/>
        <source>Welcome</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Herzlich willkommen</translation>
    </message>
</context>
</TS>
