<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="9"/>
        <source>QML Translation Demo</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Demostración de traducción de widgets</translation>
    </message>
    <message>
        <location filename="main.qml" line="25"/>
        <source>Select language</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Seleccione el idioma</translation>
    </message>
    <message>
        <location filename="main.qml" line="34"/>
        <source>English</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Inglés</translation>
    </message>
    <message>
        <location filename="main.qml" line="35"/>
        <source>German</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Alemán</translation>
    </message>
    <message>
        <location filename="main.qml" line="36"/>
        <source>Spanish</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Español</translation>
    </message>
    <message>
        <location filename="main.qml" line="14"/>
        <source>Welcome!</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>¡Bienvenidos!</translation>
    </message>
</context>
</TS>
