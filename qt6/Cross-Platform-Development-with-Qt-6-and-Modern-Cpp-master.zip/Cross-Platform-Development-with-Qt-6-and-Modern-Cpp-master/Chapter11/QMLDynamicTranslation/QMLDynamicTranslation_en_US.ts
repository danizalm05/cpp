<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="9"/>
        <source>QML Translation Demo</source>
        <oldsource>QML Dynamic Translation Demo</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.qml" line="25"/>
        <source>Select language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.qml" line="34"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.qml" line="35"/>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.qml" line="36"/>
        <source>Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.qml" line="14"/>
        <source>Welcome!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
