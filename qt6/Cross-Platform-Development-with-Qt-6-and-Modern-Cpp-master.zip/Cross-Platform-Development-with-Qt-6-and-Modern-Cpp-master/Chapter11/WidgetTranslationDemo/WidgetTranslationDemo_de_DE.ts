<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>CustomWidget</name>
    <message>
        <location filename="customwidget.ui" line="14"/>
        <source>Widget Translation Demo</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Widget-Übersetzungs-Demo</translation>
    </message>
    <message>
        <location filename="customwidget.ui" line="35"/>
        <source>Select language</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Sprache auswählen</translation>
    </message>
    <message>
        <location filename="customwidget.ui" line="43"/>
        <source>English</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Englisch</translation>
    </message>
    <message>
        <location filename="customwidget.ui" line="48"/>
        <source>German</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Deutsche</translation>
    </message>
    <message>
        <location filename="customwidget.ui" line="53"/>
        <source>Spanish</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Spanisch</translation>
    </message>
    <message>
        <location filename="customwidget.ui" line="78"/>
        <source>Welcome!</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Herzlich willkommen!</translation>
    </message>
</context>
</TS>
