<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>CustomWidget</name>
    <message>
        <location filename="customwidget.ui" line="14"/>
        <source>Widget Translation Demo</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Demostración de traducción de widgets</translation>
    </message>
    <message>
        <location filename="customwidget.ui" line="35"/>
        <source>Select language</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Seleccione el idioma</translation>
    </message>
    <message>
        <location filename="customwidget.ui" line="43"/>
        <source>English</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Inglés</translation>
    </message>
    <message>
        <location filename="customwidget.ui" line="48"/>
        <source>German</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Alemán</translation>
    </message>
    <message>
        <location filename="customwidget.ui" line="53"/>
        <source>Spanish</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Español</translation>
    </message>
    <message>
        <location filename="customwidget.ui" line="78"/>
        <source>Welcome!</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>¡Bienvenidos!</translation>
    </message>
</context>
</TS>
