<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>CustomWidget</name>
    <message>
        <location filename="customwidget.ui" line="14"/>
        <source>Widget Translation Demo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="customwidget.ui" line="35"/>
        <source>Select language</source>
        <translation></translation>
    </message>
    <message>
        <location filename="customwidget.ui" line="43"/>
        <source>English</source>
        <translation></translation>
    </message>
    <message>
        <location filename="customwidget.ui" line="48"/>
        <source>German</source>
        <translation></translation>
    </message>
    <message>
        <location filename="customwidget.ui" line="53"/>
        <source>Spanish</source>
        <translation></translation>
    </message>
    <message>
        <location filename="customwidget.ui" line="78"/>
        <source>Welcome!</source>
        <translation></translation>
    </message>
</context>
</TS>
