<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="8"/>
        <source>QML Translation Demo</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>QML-Übersetzungsdemo</translation>
    </message>
    <message>
        <location filename="main.qml" line="12"/>
        <source>Welcome</source>
        <translatorcomment>Translated by Google</translatorcomment>
        <translation>Herzlich willkommen</translation>
    </message>
</context>
</TS>
