#include "myclass.h"

MyClass::MyClass(QWidget *parent)
    : QWidget(parent)
{
}

MyClass::~MyClass()
{
}

