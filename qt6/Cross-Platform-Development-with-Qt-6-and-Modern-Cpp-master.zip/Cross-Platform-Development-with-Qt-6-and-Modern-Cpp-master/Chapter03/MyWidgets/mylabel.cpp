#include "mylabel.h"

MyLabel::MyLabel(QWidget *parent) :
    QLabel(parent)
{
}
void MyLabel::setMultiLine(bool /*isMultiline*/ )
{
    //Add logic here
}


void MyLabel::setFontCase(QFont::Capitalization /*caseOptions = QFont::MixedCase*/)
{
    //Add logic here
}
