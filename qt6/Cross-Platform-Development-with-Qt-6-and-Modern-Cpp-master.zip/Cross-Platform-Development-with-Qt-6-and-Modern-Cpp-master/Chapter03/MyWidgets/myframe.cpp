#include "myframe.h"

MyFrame::MyFrame(QWidget *parent) :
    QFrame(parent)
{
}
