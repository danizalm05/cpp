#include "customobject.h"
#include <QVariant>
CustomObject::CustomObject(QObject *parent) : QObject(parent)
{

}
